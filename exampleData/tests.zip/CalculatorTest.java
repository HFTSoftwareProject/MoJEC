import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by benno on 20.11.16.
 */
public class CalculatorTest {

    private Calculator calculator = new Calculator();

    @Test
    public void add() throws Exception {
        assertEquals(5, calculator.add(2, 3), 0.1);
    }

    @Test
    public void sub() throws Exception {
        assertEquals(-1, calculator.sub(2, 3), 0.1);
    }

    @Test
    public void mult() throws Exception {
        assertEquals(15, calculator.mult(5, 3), 0.1);
    }

    @Test
    public void div() throws Exception {
        assertEquals(5, calculator.div(15, 3), 0.1);
    }

    @Test
    public void sum() throws Exception {
        assertEquals(12, calculator.sum(3, 4, 5), 0.1);
    }

}
