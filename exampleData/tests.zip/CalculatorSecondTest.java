import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by benno on 20.11.16.
 */
public class CalculatorSecondTest {

    private Calculator calculator = new Calculator();

    @Test
    public void add2() throws Exception {
        assertEquals(5, calculator.add(2, 3), 0.1);
    }

    @Test
    public void sub2() throws Exception {
        assertEquals(-1, calculator.sub(2, 3), 0.1);
    }

    @Test
    public void mult2() throws Exception {
        assertEquals(15, calculator.mult(5, 2), 0.1);
    }

    @Test
    public void div2() throws Exception {
        assertEquals(5, calculator.div(15, 3), 0.1);
    }

    @Test
    public void sum2() throws Exception {
        assertEquals(12, calculator.sum(3, 4, 5), 0.1);
    }

}
